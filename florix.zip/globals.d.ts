declare module 'bootstrap/dist/js/bootstrap.bundle.min.js';
declare module "wow.js" {
    const WOW: any;
    export default WOW;
}